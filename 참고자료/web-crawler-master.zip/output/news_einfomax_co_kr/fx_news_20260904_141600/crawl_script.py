import os
import sys
import json
import time
import re
from datetime import datetime
from urllib.parse import urljoin
from playwright.sync_api import sync_playwright

# Project scripts path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "scripts"))

from utils import RateLimiter, detect_softblock, detect_pii, validate_values
from export_excel import export_to_excel
from domain_profile import DomainProfile
from progress import ProgressTracker

DOMAIN = "news.einfomax.co.kr"
START_URL = "https://news.einfomax.co.kr/news/articleList.html?sc_section_code=S1N16&view_type=sm"
BASE_URL = "https://news.einfomax.co.kr"

# Filtering criteria
CUTOFF_DATE = "2026.08.31 00:00"
FX_KEYWORDS = [
    "환율", "달러", "원/달러", "원·달러", "달러-원", "달러/원",
    "엔화", "엔/달러", "달러-엔", "달러/엔", "유로", "위안", "위안화",
    "외환", "외환시장", "FX", "NDF", "환시", "통화", "원화",
    "외환보유액", "환차익", "환차손", "환변동", "외환보유고"
]

def is_fx_related(title: str, lead: str) -> list[str]:
    combined = f"{title} {lead}"
    matched = []
    for kw in FX_KEYWORDS:
        if kw.lower() in combined.lower():
            matched.append(kw)
    return matched

def run_crawler():
    output_dir = CURRENT_DIR
    raw_data_file = os.path.join(output_dir, "raw_data.json")
    excel_file = os.path.join(output_dir, "crawl_result.xlsx")
    progress_file = os.path.join(output_dir, "progress.json")

    tracker = ProgressTracker(filepath=progress_file, total_estimate=100)
    limiter = RateLimiter(delay=0.7)

    all_articles = []
    consecutive_errors = 0
    max_consecutive_errors = 5
    page_num = 1
    total_scanned = 0
    earliest_date_reached = False

    # If raw_data.json already has complete data from previous crawl, load it
    if os.path.exists(raw_data_file):
        try:
            with open(raw_data_file, "r", encoding="utf-8") as f:
                cached = json.load(f)
                if len(cached) >= 100:
                    print(f"[*] Found existing raw_data.json with {len(cached)} articles. Proceeding directly to validation and export.")
                    all_articles = cached
        except Exception:
            pass

    if not all_articles:
        print(f"[*] Starting crawl: {START_URL}")
        print(f"[*] Date cutoff: >= {CUTOFF_DATE}")
        print(f"[*] Keywords: {len(FX_KEYWORDS)} items")

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
            )
            page = context.new_page()

            # Step 1: Initial visit
            page.goto(START_URL)
            page.wait_for_load_state("domcontentloaded")

            # Softblock check
            content = page.content()
            verdict = detect_softblock(content, status=200, selector_hit=bool(page.locator("ul.type2").count()))
            if verdict["blocked"]:
                print(f"[!] Softblock detected: {verdict}")
                browser.close()
                return False

            # Extract initial total parameter from pager if present
            total_param = "185125"
            first_pager_link = page.locator("ul.pagination a[href*='total=']").first
            if first_pager_link.count() > 0:
                href = first_pager_link.get_attribute("href") or ""
                m = re.search(r"total=(\d+)", href)
                if m:
                    total_param = m.group(1)
            print(f"[*] Extracted total param: {total_param}")

            while True:
                limiter.wait()
                try:
                    if page_num > 1:
                        target_url = f"https://news.einfomax.co.kr/news/articleList.html?page={page_num}&total={total_param}&box_idxno=&sc_section_code=S1N16&view_type=sm"
                        page.goto(target_url)
                        page.wait_for_load_state("domcontentloaded")

                    items = page.locator("ul.type2 > li")
                    item_count = items.count()

                    if item_count == 0:
                        print(f"[-] Page {page_num}: No items found. Stopping pagination.")
                        break

                    consecutive_errors = 0
                    page_articles_found = 0

                    for i in range(item_count):
                        total_scanned += 1
                        item = items.nth(i)

                        # Extract title & link
                        title_el = item.locator("h4.titles a")
                        title = title_el.inner_text().strip() if title_el.count() else ""
                        rel_link = title_el.get_attribute("href") if title_el.count() else ""
                        link = urljoin(BASE_URL, rel_link) if rel_link else ""

                        # Extract lead summary
                        lead_el = item.locator("p.lead a")
                        lead = lead_el.inner_text().strip() if lead_el.count() else ""

                        # Extract byline: section, author, date
                        byline_spans = item.locator("span.byline em").all_inner_texts()
                        section = byline_spans[0].strip() if len(byline_spans) > 0 else "채권/외환"
                        author = byline_spans[1].strip() if len(byline_spans) > 1 else ""
                        pub_date = byline_spans[-1].strip() if len(byline_spans) > 2 else ""

                        # Check date cutoff
                        if pub_date and pub_date < CUTOFF_DATE:
                            print(f"[*] Reached date limit at page {page_num} item {i+1}: {pub_date} < {CUTOFF_DATE}")
                            earliest_date_reached = True
                            break

                        # Check FX keyword match
                        matched_kws = is_fx_related(title, lead)
                        if matched_kws:
                            record = {
                                "기사제목": title,
                                "작성일시": pub_date,
                                "기자": author,
                                "분류": section,
                                "매칭키워드": ", ".join(matched_kws),
                                "기사요약": lead,
                                "기사링크": link
                            }
                            all_articles.append(record)
                            page_articles_found += 1

                    print(f"[+] Page {page_num:2d} done: Scanned {item_count} items, Matched {page_articles_found} FX articles (Total: {len(all_articles)})")
                    tracker.update(collected=len(all_articles), current_page=page_num)

                    # Periodically save raw data (every 50 items or every 5 pages)
                    if page_num % 5 == 0 or len(all_articles) % 50 == 0:
                        with open(raw_data_file, "w", encoding="utf-8") as f:
                            json.dump(all_articles, f, ensure_ascii=False, indent=2)

                    if earliest_date_reached:
                        break

                    page_num += 1

                except Exception as e:
                    consecutive_errors += 1
                    print(f"[!] Error on page {page_num}: {e} (consecutive: {consecutive_errors})")
                    if consecutive_errors >= max_consecutive_errors:
                        print(f"[!] Max consecutive errors reached ({max_consecutive_errors}). Aborting.")
                        break
                    page_num += 1
                    continue

            browser.close()
            print(f"\n[*] Crawling complete! Total scanned: {total_scanned}, Total FX articles collected: {len(all_articles)}")

            # Save final raw data
            if all_articles:
                with open(raw_data_file, "w", encoding="utf-8") as f:
                    json.dump(all_articles, f, ensure_ascii=False, indent=2)
                print(f"[+] Saved raw data to {raw_data_file}")
            else:
                print("[!] Warning: 0 articles collected. Not overwriting existing data.")
                return False

    # Step 5: Data Validation
    print(f"\n[*] Validating {len(all_articles)} records...")
    val_rules = {
        "기사제목": {"type": "str", "required": True, "max_empty_ratio": 0.05},
        "작성일시": {"type": "str", "required": True, "max_empty_ratio": 0.05},
        "기사링크": {"type": "str", "required": True, "max_empty_ratio": 0.05},
        "분류": {"type": "str", "required": True, "allow_uniform": True}
    }
    issues = validate_values(all_articles, val_rules)
    if issues:
        print("[!] Validation issues found:")
        for issue in issues:
            print(f"  - {issue}")
    else:
        print("[+] Value validation PASSED with 0 issues!")

    # Check PII
    pii_results = detect_pii(all_articles)
    if pii_results:
        print(f"[!] PII warning ({len(pii_results)} issues detected):")
        for pii in pii_results[:5]:
            print(f"  - {pii}")
    else:
        print("[+] PII check PASSED: No private personal info detected.")

    # Step 6: Export to Excel
    print(f"\n[*] Exporting to Excel: {excel_file}")
    export_to_excel(all_articles, excel_file)
    print(f"[+] Excel export complete: {excel_file}")

    # Step 5-A: Domain Profile Save
    print("\n[*] Saving domain profile...")
    prof_mgr = DomainProfile(base_dir=os.path.join(PROJECT_ROOT, "fingerprints"))
    prof_mgr.save(DOMAIN, {
        "domain": DOMAIN,
        "capability": "js_render",
        "fetcher_type": "playwright_spa_intercept",
        "antibot_type": "none",
        "antibot_strategy": "none",
        "site_type": "csr",
        "selectors": {
            "item_root": "ul.type2 > li",
            "title": "h4.titles a",
            "link": "h4.titles a::attr(href)",
            "lead": "p.lead a",
            "author": "span.byline em:nth-of-type(2)",
            "section": "span.byline em:nth-of-type(1)",
            "published_at": "span.byline em:last-of-type"
        },
        "pagination": {
            "type": "url_param",
            "page_param": "page",
            "total_param": "total",
            "section_param": "sc_section_code",
            "view_type": "sm"
        },
        "notes": "연합인포맥스 채권/외환 기사목록. 세션 없는 단발 HTTP 요청 시 페이지 리셋되므로 Playwright 브라우저 컨텍스트를 유지하여 page.goto(page=N&total=...&box_idxno=&sc_section_code=S1N16&view_type=sm)로 순회함.",
        "last_used": str(datetime.now().date())
    })
    print(f"[+] Domain profile saved for {DOMAIN}")
    tracker.complete()

    return True

if __name__ == "__main__":
    success = run_crawler()
    sys.exit(0 if success else 1)
